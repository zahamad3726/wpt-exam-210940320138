import logo from "./logo.svg";
import "./App.css";
import { useState } from "react";
import axios from "axios";
<link rel="stylesheet" href="App.cs" />

function App() {
  return (
    <>
      <Header />
      <Whatsapp />
      < msgsend />
    </>
  );
}
function Header() {
  return (
    <div className="">
      <div className="bg-secondary text-light p-3 m-3">
        MychatApp
        <div>by (138_Zuber Ahamad_kh)</div>
      </div>
    </div>
  );
}
function Whatsapp(){
  return (
  <div className="">
    <input type="text" placeholder="Lets chat here...." className="p-3 letschat1 m-3" name="" id="" />
    <input type="button" value="SEND" onClick={msgsend()} className="p-3 letschat2 m-3" />
  </div>
  );
}
function msgsend(){
  return(
  console.log("message sent....")
  );}

export default App;
