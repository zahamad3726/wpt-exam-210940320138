const mysql= require('mysql');
const promise= require('bluebird');
promise.promisifyAll(require("mysql/lib/Connection").prototype);
const dbinfo={
    host: "localhost",
    user:"root",
    password:"cdac",
    database:"wptexam"
};
const record={
    sender:"zuber",
    receiver:"vivek",
    msg:"Hi dear"
}
const addRecord= async (record)=>{
    const connection=mysql.createConnection(dbinfo);
    await connection.connectAsync();
    const sql='insert into message(sender,receiver,msg) values(? ? ?)';
    await connection.queryAsync(sql,[record.sender,record.receiver,record.msg]);
    await connection.endAsync();
    console.log("mesaage record added.....!");
}

const addRecord = async(record)=>{
    const connection=mysql.createConnection(dbinfo);
    await connection.connectAsync();
    const sql='insert into message (sender,receiver,msg) values(? ? ?)';
    await connection.queryAsync(sql,[record.sender,record.receiver,record.msg]);
    await connection.endAsync();
    console.log("mesaage record added....!!");
}

const getRecord=async()=>{
    const connection=mysql.createConnection(dbinfo);
    await connection.connectAsync();
    const sql='select * from message';
    const list=await connection.queryAsync(sql,[]);
    await connection.endAsync();
    console.log("list of record.....!!");
    console.log(list);
    return list;
}
getRecord()
module.exports={addRecord,getRecord};